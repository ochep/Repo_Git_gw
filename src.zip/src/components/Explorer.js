import React from "react";
import Typography from "@material-ui/core/Typography";


class Explorer extends React.Component {
  render() {
    return (
      <div>
          <Typography>
              Exporer Page
          </Typography>
          <Typography>
              Exporer Page
          </Typography>
          <Typography>
              Exporer Page
          </Typography>
          <Typography>
              Exporer Page
          </Typography>
          <Typography>
              Exporer Page
          </Typography>
          <h3> Test </h3>
      </div>
    );
  }
}




export default Explorer;
