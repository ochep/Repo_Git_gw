import {createStore,combineReducers } from 'redux'
import memberReducer from '../reducers/members' 
import appReducer from '../reducers/app' 

const reducers = combineReducers({
    members : memberReducer,
    app :appReducer
})

export default createStore (reducers)