const intialState = {
    userData: [],
    userTotal: 0,
}

const memberReducer = (state = intialState, action) => {
    switch (action.type) {
        default:
            return state
    }
}

export default memberReducer