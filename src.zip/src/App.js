import React from "react";
import "./App.css";
import MyToolbar from "./components/Mytoolbar";
import Footers from "./components/Footers";
import axios from "axios";
import Explorer from "./components/Explorer";
import Home from "./components/Home";
import Profile from "./components/Profile";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { Provider } from "react-redux";
import myStore from "./components/config/store";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      eventDetail: {
        judul: "Hacktiv8 Meetup",
        lokasi: "Jakarta",
        members: 1201,
        orgainzer: "iboy",
        image:
          "https://hacktiv8.com/img/logo-01--md5--0f4f1c19c0064d527c72d44cfe007a08.png"
      },
      meetUp: {
        judulMeetup: "Meetup iboy",
        tglMeetup: "11 October 2018",
        subjectMeetup:
          "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur subtitle2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur body1. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur unde suscipit, quam beatae rerum inventore consectetur, neque doloribus, cupiditate numquam dignissimos laborum fugiat deleniti? Eum quasi quidem quibusdam."
      },
      aboutmeetUp: {
        aboutTittle:
          "body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur unde suscipit.",
        twitterMeetup: "Twitter@ iboyganteng"
      },
      member: {
        avatarImg: "https://material-ui.com/static/images/uxceo-128.jpg",
        organizer: "ishak iboy",
        other: 4
      },
      people: [],
      films: []
    };
  }
  handleEditEvent(event) {
    this.setState({
      eventDetail: event
    });
  }

  componentDidMount() {
    axios
      .get("https://reqres.in/api/users?page=2")
      .then(response => response.data.data)
      .then(membersData => {
        this.setState({
          people: membersData
        });
      });

    axios
      .get("https://swapi.co/api/films/")
      .then(response => response.data.results.slice(0, 4))
      .then(filmData => {
        this.setState({
          films: filmData
        });
      });
  }

  render() {
    const {
      eventDetail,
      meetUp,
      aboutmeetUp,
      member,
      members,
      people,
      films
    } = this.state;
    const { match } = this.props;
    return (
      <Provider store={myStore}>
        <div className="App">
          <Router>
            <div>
              <MyToolbar />
              <Route exact path="/" component={Home} />
              <Route path="/explorer" component={Explorer} />
              <Route path={`/profile/:topicId`} component={Profile} />
            </div>
          </Router>
          <Footers />
        </div>
      </Provider>
    );
  }
}

export default App;
